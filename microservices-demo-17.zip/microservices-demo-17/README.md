# Running the application
- Please enter the correct credentials in twitter4j.properties file.
- Then run TwitterToKafkaServiceApplication inside IntelliJ, or run with mvn spring-boot:run command
- Check the KafkaProducerConfigData in app-config-data module and the kafka-producer-config prefix in application.yml file 
where we set the producer configuration