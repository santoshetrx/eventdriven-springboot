# Running the application
- Please enter the correct credentials in twitter4j.properties file.
- Then run TwitterToKafkaServiceApplication inside IntelliJ, or run with mvn spring-boot:run command
- To use the mock tweets, set enable-mock-tweets: true in application.yml file
- Observe that we moved the TwitterToKafkaServiceConfigData to a new module called app-config-data

